## Problem and change

Describe the player-visible behavior and any data/config migration.

## Validation

- Compiler/version and result:
- Automated checks:
- In-game tests and environment:
- Untested paths or limitations:

Confirm no private server data or credentials are included.
